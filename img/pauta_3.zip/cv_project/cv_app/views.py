from django.shortcuts import render, get_object_or_404, redirect
from .models import CV, Ciudad
from .forms import CVForm
from django.db.models import Q

def ingresar_cv(request):
    if request.method == 'POST':
        form = CVForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('listar_cvs')
    else:
        form = CVForm()
    return render(request, 'ingresar_cv.html', {'form': form})

def listar_cvs(request):
    cvs = CV.objects.all()
    edad = request.GET.get('edad')
    ciudad = request.GET.get('ciudad')
    palabra = request.GET.get('palabra')

    if edad:
        cvs = [cv for cv in cvs if cv.edad == int(edad)]
    if ciudad:
        cvs = cvs.filter(ciudad__id=ciudad)
    if palabra:
        cvs = cvs.filter(descripcion__icontains=palabra)

    ciudades = Ciudad.objects.all()
    return render(request, 'listar_cvs.html', {'cvs': cvs, 'ciudades': ciudades})

def detalle_cv(request, cv_id):
    cv = get_object_or_404(CV, id=cv_id)
    return render(request, 'detalle_cv.html', {'cv': cv, 'foto_base64': cv.foto})

def inicio(request):
    return render(request, 'inicio.html')
