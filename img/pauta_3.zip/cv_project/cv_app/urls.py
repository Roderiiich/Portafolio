from django.urls import path
from . import views

urlpatterns = [
    path('', views.inicio, name='inicio'),
    path('ingresar/', views.ingresar_cv, name='ingresar_cv'),
    path('listar/', views.listar_cvs, name='listar_cvs'),
    path('detalle/<int:cv_id>/', views.detalle_cv, name='detalle_cv'),

]
